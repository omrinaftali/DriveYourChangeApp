package il.ac.pac.driveyourchangeapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FieldPath;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class AdivDriver extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private TextView greenstar_DB, yellowstar_DB, purplestar_DB, sumAdiv;
    int sum ,green, yellow, purple , adivTag;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adiv_driver);

        greenstar_DB = findViewById(R.id.greenstar_DB);
        yellowstar_DB = findViewById(R.id.yellowstar_DB);
        purplestar_DB = findViewById(R.id.purplestar_DB);
        sumAdiv = findViewById(R.id.sumAdiv);

        mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        String driverid = currentUser.getUid();

        FirebaseFirestore db = FirebaseFirestore.getInstance();

        CollectionReference drivers = db.collection("Drivers_Points");
        Query query = drivers.whereEqualTo(FieldPath.documentId(), driverid);
        query.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        Log.d("exist", document.getId() + " => " + document.getData());
                        if((document.getLong("green_stars")) == null){
                            green = 0;}
                        else{
                            green = Math.toIntExact(document.getLong("green_stars"));}
                        greenstar_DB.setText(String.valueOf(green)+ "/10");

                        if((document.getLong("yellow_stars")) == null){
                            yellow = 0;}
                        else{
                            yellow = Math.toIntExact(document.getLong("yellow_stars"));}
                        yellowstar_DB.setText(String.valueOf(yellow)+ "/10");

                        if((document.getLong("purple_stars")) == null){
                            purple = 0;}
                        else{
                            purple = Math.toIntExact(document.getLong("purple_stars"));}
                        purplestar_DB.setText(String.valueOf(purple) + "/10");

                    }
                } else {
                    Log.d("error", "Error getting documents: ", task.getException());
                }

            }
        });

        CollectionReference driversTag = db.collection("Drivers_Tags");
        Query queryTag = driversTag.whereEqualTo(FieldPath.documentId(), driverid);
        queryTag.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        Log.d("exist", document.getId() + " => " + document.getData());
                        if ((document.getLong("Adiv_tag")) == null) {
                            sum = 0;
                        } else {
                            sum = Math.toIntExact(document.getLong("Adiv_tag"));
                        }
                        sumAdiv.setText(String.valueOf(sum));
                    }
                }
                else {
                    Log.d("error", "Error getting documents: ", task.getException());
                    sumAdiv.setText(String.valueOf(0));
                }
            }

        });
        configureToHomeFromAdivButton();
    }

    private void configureToHomeFromAdivButton(){
        ImageButton ToHomeFromAdivButton = (ImageButton) findViewById(R.id.homeFromAdivBTN);
        ToHomeFromAdivButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(AdivDriver.this, ReportMainScreen.class));
            }
        });
    }

    }