package il.ac.pac.driveyourchangeapp;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class Car {

    private String licensePlate;
    private int year;
    private String model , driverId;

    public Car(String licensePlate, int year, String model, String driverId) {
        this.licensePlate = licensePlate;
        this.year = year;
        this.model = model;
        this.driverId = driverId;
    }

    final FirebaseFirestore db = FirebaseFirestore.getInstance();
    CollectionReference Cars = db.collection("Cars");


    public Map<String, Object> toMap() {
        final Map<String, Object> map = new HashMap<>();
        map.put("year", this.year);
        map.put("licensePlate", this.licensePlate);
        map.put("model", this.model);
        map.put("driverId", this.driverId);
        Cars.document(licensePlate).set(map);
        return map;
    }

    public static Car fromMap(Map<String, Object> data) {
        final int year = (int) data.get("year");
        final String licensePlate = (String)  data.get("licensePlate");
        final String model = (String) data.get("model");
        final String driverId = (String) data.get("driverId");
        return new Car(licensePlate, year, model,driverId);
    }

    public void setlicensePlate(String newlicensePlate) {
        this.licensePlate = newlicensePlate;
        onUpdate();
    }

    public void setYear(int newYear) {
        this.year = newYear;
        onUpdate();
    }

    public void setModel(String newModel) {
        this.model = newModel;
        onUpdate();
    }

    private void onUpdate() {
        // FirebaseFirestore db = FirebaseFirestore.getInstance();
        // db.collection().document().update(this.toMap()).
    }


//
//    public String uid;
//    public String author;
//    public String title;
//    public String body;
//    public int starCount = 0;
//    public Map<String, Boolean> stars = new HashMap<>();
//
//
//
//    private static final String TAG = "DocSnippets";
//
//    private static final ThreadPoolExecutor EXECUTOR = new ThreadPoolExecutor(2, 4,
//            60, TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>());
//
//    public final FirebaseFirestore db;
//
//    DocSnippets(FirebaseFirestore db) {
//        this.db = db;
//    }
//    public void setup() {
//        // [START get_firestore_instance]
//        FirebaseFirestore db = FirebaseFirestore.getInstance();
//        // [END get_firestore_instance]
//
//        // [START set_firestore_settings]
//        FirebaseFirestoreSettings settings = new FirebaseFirestoreSettings.Builder()
//                .setPersistenceEnabled(true)
//                .build();
//        db.setFirestoreSettings(settings);
//        // [END set_firestore_settings]
//    }


}
