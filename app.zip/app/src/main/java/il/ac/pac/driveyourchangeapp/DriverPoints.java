package il.ac.pac.driveyourchangeapp;


import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class DriverPoints {

    private String driver_id;
    private int pink_stars;

    public DriverPoints(String driver_id, int pink_stars) {
        this.driver_id = driver_id;
        this.pink_stars = pink_stars;
    }

    final FirebaseFirestore db = FirebaseFirestore.getInstance();
    CollectionReference DriverPoints = db.collection("Driver_Points");


    public Map<String, Object> toMap() {
        final Map<String, Object> map = new HashMap<>();
//        map.put("driver_id", this.driver_id);
        map.put("pink_stars", this.pink_stars);
        DriverPoints.document(driver_id).set(map);
        return map;
    }

    public static DriverPoints fromMap(Map<String, Object> data) {
        final String driver_id = (String) data.get("driver_id");
        final int pink_stars = (int) data.get("pink_stars");
        return new DriverPoints(driver_id, pink_stars);
    }

}