//package il.ac.pac.driveyourchangeapp;
//
//import androidx.appcompat.app.AppCompatActivity;
//
//import android.os.Bundle;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import com.google.android.gms.tasks.OnSuccessListener;
//import com.google.firebase.firestore.DocumentReference;
//import com.google.firebase.firestore.DocumentSnapshot;
//import com.google.firebase.firestore.FirebaseFirestore;
//
//public class PageToTest extends AppCompatActivity {
//    private TextView test1234;
//
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_page_to_test);
//
//        test1234 = findViewById(R.id.test1234);
//
//        //test1234.setText("Blah blah blah");
//
////        loadNote();
//    }
//
//    public void loadNote(){
//        String reportedCarNumber = ("1234567");
//        final FirebaseFirestore db = FirebaseFirestore.getInstance();
//
//        DocumentReference Cars = db.collection("Cars").document(reportedCarNumber);
//        Cars.get()
//                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
//                    @Override
//                    public void onSuccess(DocumentSnapshot documentSnapshot) {
//                        if (documentSnapshot.exists()) {
//                            String ReportedDriverID = documentSnapshot.getString("driver_id");
//
//                            //Map<String, Object> note = documentSnapshot.getData();
//                            test1234.setText(ReportedDriverID);
//                        } else {
//                            Toast.makeText(PageToTest.this, "Document does not exist", Toast.LENGTH_SHORT).show();
//                        }
//                    }
//                });
//
//    }
//
//
//}