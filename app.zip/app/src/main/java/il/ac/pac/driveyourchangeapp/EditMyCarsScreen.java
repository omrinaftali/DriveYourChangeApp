package il.ac.pac.driveyourchangeapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class EditMyCarsScreen extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private EditText carNumberTextView, carModelTextView, carYearTextView;
    private Button BtnUpdateCars;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_my_cars_screen);

        configureToHomeButton();

        // initialising all views through id defined above
        carNumberTextView = findViewById(R.id.car_number);
        carModelTextView = findViewById(R.id.car_model);
        carYearTextView = findViewById(R.id.car_year);
        BtnUpdateCars = findViewById(R.id.updateBTNFromCars);

        // Set on Click Listener on Registration button
        BtnUpdateCars.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertNewCar();
            }
        });
    }

    private void insertNewCar() {
        // Take the value of two edit texts in Strings
        String carNumber = carNumberTextView.getText().toString();
        String carModel = carModelTextView.getText().toString();
        String carYear = carYearTextView.getText().toString();
        mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        String driverid = currentUser.getUid();

        // Validations for input email and password
        if (TextUtils.isEmpty(carNumber)) {
            Toast.makeText(getApplicationContext(),
                            "Please enter Car Number!",
                            Toast.LENGTH_LONG)
                    .show();
            return;
        }
        if (TextUtils.isEmpty(carModel)) {
            Toast.makeText(getApplicationContext(),
                            "Please enter Car Model!",
                            Toast.LENGTH_LONG)
                    .show();
            return;
        }
        if (TextUtils.isEmpty(carYear)) {
            Toast.makeText(getApplicationContext(),
                            "Please enter Car Year!",
                            Toast.LENGTH_LONG)
                    .show();
            return;
        }

        Map<String, Object> car = new HashMap<>();
        car.put("model", carModel);
        car.put("year_manufacture", carYear);
        car.put("driver_id",driverid);

        final FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("Cars").document(carNumber)
                .set(car)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    private static final String TAG = "exist";

                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "DocumentSnapshot successfully written!");
                        Toast.makeText(getApplicationContext(),
                                        "Added successfully!",
                                        Toast.LENGTH_LONG)
                                .show();
                        startActivity(new Intent(EditMyCarsScreen.this, PersonalAreaScreen.class));
                    }
                })

                .addOnFailureListener(new OnFailureListener() {
                    private static final String TAG = "error";

                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error writing document", e);
                    }
                });
    }

        private void configureToHomeButton(){
            ImageButton toHomeButtonFromEditMyCars = (ImageButton) findViewById(R.id.homeFromEditMyCarsBTN);
            toHomeButtonFromEditMyCars.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    startActivity(new Intent(EditMyCarsScreen.this, ReportMainScreen.class));
                }
            });
        }

}