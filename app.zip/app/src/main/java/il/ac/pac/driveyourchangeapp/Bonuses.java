 package il.ac.pac.driveyourchangeapp;

 import android.content.Intent;
 import android.os.Bundle;
 import android.view.View;
 import android.widget.ImageButton;

 import androidx.appcompat.app.AppCompatActivity;

 import com.google.firebase.auth.FirebaseAuth;
 import com.google.firebase.firestore.QuerySnapshot;
 import com.smarteist.autoimageslider.IndicatorView.animation.type.IndicatorAnimationType;
 import com.smarteist.autoimageslider.SliderAnimations;
 import com.smarteist.autoimageslider.SliderView;


 public class Bonuses extends AppCompatActivity {


     int cafe_maafe = R.drawable.cafe_maafe;
     int artikinshekel = R.drawable.artikinshekel;
     int hanahainbituah = R.drawable.hanahainbituah;
     int sfipahamisithinam = R.drawable.sfipahamisithinam;
     int rihanlaoto = R.drawable.rihanlaoto;

     int bdikahinam_gray = R.drawable.bdikahinam_gray;
     int pancher_gray = R.drawable.pancher_gray;
     int sandwich_gray = R.drawable.sandwich_gray;
     int tipullarehev_gray = R.drawable.tipullarehev_gray;
     int maamadlatelefon_gray = R.drawable.maamadlatelefon_gray;


     SliderView sliderView;
     int[] images = {cafe_maafe, artikinshekel,hanahainbituah,sfipahamisithinam, rihanlaoto};

     SliderView sliderView2;
     int[] images2 = {bdikahinam_gray,pancher_gray,sandwich_gray,tipullarehev_gray,maamadlatelefon_gray};


     @Override
     protected void onCreate(Bundle savedInstanceState) {
         super.onCreate(savedInstanceState);
         setContentView(R.layout.activity_bonuses);

         sliderView = findViewById(R.id.image_slider);
         sliderView2 = findViewById(R.id.image_slider2);


         SliderAdapter sliderAdapter = new SliderAdapter(images);
         SliderAdapter sliderAdapter2 = new SliderAdapter(images2);


         sliderView.setSliderAdapter(sliderAdapter);
         sliderView.setIndicatorAnimation(IndicatorAnimationType.WORM);
         sliderView.setSliderTransformAnimation(SliderAnimations.DEPTHTRANSFORMATION);
         sliderView.startAutoCycle();

         sliderView2.setSliderAdapter(sliderAdapter2);
         sliderView2.setIndicatorAnimation(IndicatorAnimationType.WORM);
         sliderView2.setSliderTransformAnimation(SliderAnimations.DEPTHTRANSFORMATION);
         sliderView2.startAutoCycle();

         configureToMyBonusesFromBounusesButton();
         configureToHoneFromMyBonusesButton();

     }

     private void configureToMyBonusesFromBounusesButton(){
         ImageButton ToMyBonusesButton = (ImageButton) findViewById(R.id.tomybonuses);
         ToMyBonusesButton.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 startActivity(new Intent(Bonuses.this, MyBonuses.class));
             }
         });
     }

     private void configureToHoneFromMyBonusesButton(){
         ImageButton ToHoneFromMyBonusesButton = (ImageButton) findViewById(R.id.homeFromBonuses);
         ToHoneFromMyBonusesButton.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 startActivity(new Intent(Bonuses.this, ReportMainScreen.class));
             }
         });
     }



 }
 //toBonusDetails