package il.ac.pac.driveyourchangeapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class BonusDetailsForCoffeeWithBarcode extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private TextView bonusBarcode_DB;
    private TextView Chosen_Bonus_title_DB, Chosen_Bonus_area_DB, Chosen_expired_date_DB,Chosen_Conditions_DB,Chosen_notes_DB;
    private ImageView Chosen_Bonus_image;
//    String Chosen_bonusImageName = String.valueOf(Chosen_Bonus_image.getTag());

    String test = "cafe_maafe";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bonus_details_for_coffee_with_barcode);

        Chosen_Bonus_image = findViewById(R.id.Chosen_cafe_maafe);

        Chosen_Bonus_title_DB = findViewById(R.id.Chosen_Bonus_title_DB);
        Chosen_Bonus_area_DB = findViewById(R.id.Chosen_Bonus_area_DB);
        Chosen_expired_date_DB = findViewById(R.id.Chosen_expired_date_DB);
        Chosen_Conditions_DB = findViewById(R.id.Chosen_Conditions_DB);
        Chosen_notes_DB = findViewById(R.id.Chosen_notes_DB);
        mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        String driverid = currentUser.getUid();
        FirebaseFirestore db = FirebaseFirestore.getInstance();


        CollectionReference Bonuses = db.collection("Bonuses");
        Query query_bonus = Bonuses.whereEqualTo("bonus_name", "cafe_maafe");
        query_bonus.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        Log.d("exist", document.getId() + " => " + document.getData());
                        Chosen_Bonus_title_DB.setText(document.getString("title"));
                        Chosen_Bonus_area_DB.setText(document.getString("area"));
                        Chosen_expired_date_DB.setText(document.getString("expired_date"));
                        Chosen_Conditions_DB.setText(document.getString("Conditions"));
                        Chosen_notes_DB.setText(document.getString("notes"));
                    }
                } else {
                    Log.d("error", "Error getting documents: ", task.getException());
                }
            }
        });

        bonusBarcode_DB = findViewById(R.id.bonusBarcode_DB);

        CollectionReference BonusDrivers = db.collection("Bonus_Drivers");
        Query query_driver_bonus = BonusDrivers.whereEqualTo("driver_id", driverid);
        query_driver_bonus.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        Log.d("exist", document.getId() + " => " + document.getData());
                        bonusBarcode_DB.setText(document.getId());
                    }
                } else {
                    Log.d("error", "Error getting documents: ", task.getException());
                }
            }
        });
        configureToHomeButtonFromCofeeWithBarcode();
    }



    private void configureToHomeButtonFromCofeeWithBarcode(){
        ImageButton toHomeButtonFromMyCars = (ImageButton) findViewById(R.id.homeFromCoffeeWithBarcodeBTN);
        toHomeButtonFromMyCars.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(BonusDetailsForCoffeeWithBarcode.this, ReportMainScreen.class));
            }
        });
    }
}