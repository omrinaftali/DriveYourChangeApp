package il.ac.pac.driveyourchangeapp;

import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class Driver {
    private String fname,lname,email,userID, phone;;

    public Driver(String userid, String email, String fname,String lname, String phone){
        this.email=email;
        this.fname=fname;
        this.lname=lname;
        this.userID=userid;//UID
        this.phone = phone;
    }


    final FirebaseFirestore db = FirebaseFirestore.getInstance();
    CollectionReference Drivers = db.collection("Drivers");

    public Map<String,String> toMap(){
        //TODO: finish this method
        Map<String,String> map=new HashMap<>();
        map.put("email",this.email);
        map.put("fname",this.fname);
        map.put("lname",this.lname);
        map.put("userID",this.userID);
        map.put("phone",this.phone);
        Drivers.document(userID).set(map);
        return map;
    }

    public static Driver fromMap(Map<String,Object> data){
        //TODO: Implement this!!!
        final String email = (String) data.get("email");
        final String fname = (String) data.get("fname");
        final String lname = (String) data.get("lname");
        final String userID = (String) data.get("userID");
        final String phone = (String) data.get("phone");
        return new Driver(email,userID,fname,lname,phone);
    }

    public void setEmail(String newEmail) {
        this.email = newEmail;
//        onUpdate();
    }
    public void setFname(String newFname) {
        this.fname = newFname;
        toMap();
    }
    public void setLname(String newLname) {
        this.lname = newLname;
//        onUpdate();
    }
    public void setPhone(String newPhone) {
        this.phone = newPhone;
//        onUpdate();
    }

    private void onUpdate() {
        // FirebaseFirestore db = FirebaseFirestore.getInstance();
        // db.collection().document().update(this.toMap()).
    }
}
