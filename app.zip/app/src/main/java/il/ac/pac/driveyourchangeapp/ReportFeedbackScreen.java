package il.ac.pac.driveyourchangeapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldPath;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.Map;

public class ReportFeedbackScreen extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private TextView ReportedDriverIDtextView;
    int adivTag;

    final FirebaseFirestore db = FirebaseFirestore.getInstance();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_feedback_screen);
        configureToHomeButton();
        afterReportStopSign();
        afterReportMatanZhutKdima();
        afterReportStopForMan();
        afterReportIstalvut();
        afterReportBackToRight();
        afterReportItut();
//        checkForTagAdiv();
    }

    private void configureToHomeButton() {
        ImageButton toHomeButton = (ImageButton) findViewById(R.id.homeFronFeedbackBTN);
        toHomeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ReportFeedbackScreen.this, ReportMainScreen.class));
            }
        });
    }

    private void afterReportStopSign() {
        Bundle extras = getIntent().getExtras();
        String car_number = extras.getString("ReportedCarKey");
        //The key argument here must match that used in the other activity
        final FirebaseFirestore db = FirebaseFirestore.getInstance();
        ImageButton afterReportStopSignButton = (ImageButton) findViewById(R.id.stopSign);

        afterReportStopSignButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mAuth = FirebaseAuth.getInstance();
                FirebaseUser currentUser = mAuth.getCurrentUser();
                String driverid = currentUser.getUid(); //  Get the ID of the reporter driver

                //pointsToReportedDriver
                DocumentReference ReportedCarDoc = db.collection("Cars").document(car_number);   //  Get the FireStore document of the reported car
                ReportedCarDoc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            String ReportedDriverID = task.getResult().getString("driver_id");  // The id of the reported driver
                            DocumentReference PointToDriver = db.collection("Drivers_Points").document(ReportedDriverID);   //   Get the FireStore "points of driver" document
                            if (ReportedDriverID.equals(driverid)) {    // check if the driver trying to report on himself
                                Toast.makeText(getApplicationContext(),
                                                "Self Reported Not Allowed!",
                                                Toast.LENGTH_LONG)
                                        .show();
                                startActivity(new Intent(ReportFeedbackScreen.this, ReportMainScreen.class));
                            }

                            PointToDriver.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                    if (task.isSuccessful()) {
                                        DocumentSnapshot document = task.getResult();
                                        if (document.exists()) {    // check if FireStore points document exists for the reported driver
                                            // if exists, update fields according to report type:
                                            Log.d("exist", "Document exists!");
                                            PointToDriver.update("red_stars", FieldValue.increment(1));
                                            PointToDriver.update("green_stars", FieldValue.increment(0));
                                            PointToDriver.update("yellow_stars", FieldValue.increment(0));
                                            PointToDriver.update("blue_stars", FieldValue.increment(0));
                                            PointToDriver.update("purple_stars", FieldValue.increment(0));
                                            PointToDriver.update("orange_stars", FieldValue.increment(0));
                                            checkForTagZahir();

                                        } else {    // if FireStore points document NOT exists
                                            // means that it's the first time someone report on this driver
                                            Log.d("not exist", "Document does not exist!");
                                            Map<String, Object> DriverPoints = new HashMap<>(); // Create DriverPoints object and put data according to report type
                                            DriverPoints.put("red_stars", FieldValue.increment(1));
                                            DriverPoints.put("green_stars", FieldValue.increment(0));
                                            DriverPoints.put("yellow_stars", FieldValue.increment(0));
                                            DriverPoints.put("blue_stars", FieldValue.increment(0));
                                            DriverPoints.put("purple_stars", FieldValue.increment(0));
                                            DriverPoints.put("orange_stars", FieldValue.increment(0));
                                            PointToDriver.set(DriverPoints) // Create the FireStore points document to the driver
                                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                        private static final String TAG = "exist";

                                                        @Override
                                                        public void onSuccess(Void aVoid) {
                                                            Log.d(TAG, "DocumentSnapshot successfully written!");
                                                        }
                                                    })

                                                    .addOnFailureListener(new OnFailureListener() {
                                                        private static final String TAG = "error";

                                                        @Override
                                                        public void onFailure(@NonNull Exception e) {
                                                            Log.w(TAG, "Error writing document", e);
                                                        }
                                                    });
                                        }
                                    } else {
                                        Log.d("failed", "Failed with: ", task.getException());
                                    }
                                }
                            });

                            //  handles the pointsToReporterDriver - נהג מפרגן
                            db.collection("Drivers_Points").document(driverid)
                                    .update("pink_stars", FieldValue.increment(1))
                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                        private static final String TAG = "exist";

                                        @Override
                                        public void onSuccess(Void aVoid) {
                                            Log.d(TAG, "DocumentSnapshot successfully written!");
                                            Toast.makeText(getApplicationContext(),
                                                            "Added successfully!",
                                                            Toast.LENGTH_LONG)
                                                    .show();
                                            startActivity(new Intent(ReportFeedbackScreen.this, ReportMainScreen.class));
                                        }
                                    })

                                    .addOnFailureListener(new OnFailureListener() {
                                        private static final String TAG = "error";

                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            Log.w(TAG, "Error writing document", e);
                                        }
                                    });
                        }
                    }
                });
            }
        });
    }


    private void afterReportMatanZhutKdima() {
        Bundle extras = getIntent().getExtras();
        String car_number = extras.getString("ReportedCarKey");
        final FirebaseFirestore db = FirebaseFirestore.getInstance();
        ImageButton afterReportMatanZhutKdimaButton = (ImageButton) findViewById(R.id.MatanZhutKdima);

        afterReportMatanZhutKdimaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mAuth = FirebaseAuth.getInstance();
                FirebaseUser currentUser = mAuth.getCurrentUser();
                String driverid = currentUser.getUid(); //  Get the ID of the reporter driver

                //pointsToReportedDriver
                DocumentReference ReportedCarDoc = db.collection("Cars").document(car_number);   //  Get the FireStore document of the reported car
                ReportedCarDoc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            String ReportedDriverID = task.getResult().getString("driver_id");  // The id of the reported driver
                            DocumentReference PointToDriver = db.collection("Drivers_Points").document(ReportedDriverID);   //   Get the FireStore "points of driver" document
                            if (ReportedDriverID.equals(driverid)) {    // check if the driver trying to report on himself
                                Toast.makeText(getApplicationContext(),
                                                "Self Reported Not Allowed!",
                                                Toast.LENGTH_LONG)
                                        .show();
                                startActivity(new Intent(ReportFeedbackScreen.this, ReportMainScreen.class));
                            }

                            PointToDriver.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                    if (task.isSuccessful()) {
                                        DocumentSnapshot document = task.getResult();
                                        if (document.exists()) {    // check if FireStore points document exists for the reported driver
                                            // if exists, update fields according to report type:
                                            Log.d("exist", "Document exists!");
                                            PointToDriver.update("yellow_stars", FieldValue.increment(1));
                                            PointToDriver.update("green_stars", FieldValue.increment(0));
                                            PointToDriver.update("red_stars", FieldValue.increment(0));
                                            PointToDriver.update("blue_stars", FieldValue.increment(0));
                                            PointToDriver.update("purple_stars", FieldValue.increment(0));
                                            PointToDriver.update("orange_stars", FieldValue.increment(0));
                                            checkForTagAdiv();

                                        } else {    // if FireStore points document NOT exists
                                            // means that it's the first time someone report on this driver
                                            Log.d("not exist", "Document does not exist!");
                                            Map<String, Object> DriverPoints = new HashMap<>(); // Create DriverPoints object and put data according to report type
                                            DriverPoints.put("yellow_stars", FieldValue.increment(1));
                                            DriverPoints.put("red_stars", FieldValue.increment(0));
                                            DriverPoints.put("green_stars", FieldValue.increment(0));
                                            DriverPoints.put("blue_stars", FieldValue.increment(0));
                                            DriverPoints.put("purple_stars", FieldValue.increment(0));
                                            DriverPoints.put("orange_stars", FieldValue.increment(0));
                                            PointToDriver.set(DriverPoints) // Create the FireStore points document to the driver
                                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                        private static final String TAG = "exist";

                                                        @Override
                                                        public void onSuccess(Void aVoid) {
                                                            Log.d(TAG, "DocumentSnapshot successfully written!");
                                                        }
                                                    })

                                                    .addOnFailureListener(new OnFailureListener() {
                                                        private static final String TAG = "error";

                                                        @Override
                                                        public void onFailure(@NonNull Exception e) {
                                                            Log.w(TAG, "Error writing document", e);
                                                        }
                                                    });
                                        }
                                    } else {
                                        Log.d("failed", "Failed with: ", task.getException());
                                    }
                                }
                            });

                            //  handles the pointsToReporterDriver - נהג מפרגן
                            db.collection("Drivers_Points").document(driverid)
                                    .update("pink_stars", FieldValue.increment(1))
                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                        private static final String TAG = "exist";

                                        @Override
                                        public void onSuccess(Void aVoid) {
                                            Log.d(TAG, "DocumentSnapshot successfully written!");
                                            Toast.makeText(getApplicationContext(),
                                                            "Added successfully!",
                                                            Toast.LENGTH_LONG)
                                                    .show();
                                            startActivity(new Intent(ReportFeedbackScreen.this, ReportMainScreen.class));
                                        }
                                    })

                                    .addOnFailureListener(new OnFailureListener() {
                                        private static final String TAG = "error";

                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            Log.w(TAG, "Error writing document", e);
                                        }
                                    });
                        }
                    }
                });
            }
        });
    }

    private void afterReportStopForMan() {
        Bundle extras = getIntent().getExtras();
        String car_number = extras.getString("ReportedCarKey");
        //The key argument here must match that used in the other activity
        final FirebaseFirestore db = FirebaseFirestore.getInstance();
        ImageButton afterReportStopForManButton = (ImageButton) findViewById(R.id.stopforman);

        afterReportStopForManButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mAuth = FirebaseAuth.getInstance();
                FirebaseUser currentUser = mAuth.getCurrentUser();
                String driverid = currentUser.getUid(); //  Get the ID of the reporter driver

                //pointsToReportedDriver
                DocumentReference ReportedCarDoc = db.collection("Cars").document(car_number);   //  Get the FireStore document of the reported car
                ReportedCarDoc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            String ReportedDriverID = task.getResult().getString("driver_id");  // The id of the reported driver
                            DocumentReference PointToDriver = db.collection("Drivers_Points").document(ReportedDriverID);   //   Get the FireStore "points of driver" document
                            if (ReportedDriverID.equals(driverid)) {    // check if the driver trying to report on himself
                                Toast.makeText(getApplicationContext(),
                                                "Self Reported Not Allowed!",
                                                Toast.LENGTH_LONG)
                                        .show();
                                startActivity(new Intent(ReportFeedbackScreen.this, ReportMainScreen.class));
                            }

                            PointToDriver.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                    if (task.isSuccessful()) {
                                        DocumentSnapshot document = task.getResult();
                                        if (document.exists()) {    // check if FireStore points document exists for the reported driver
                                            // if exists, update fields according to report type:
                                            Log.d("exist", "Document exists!");
                                            PointToDriver.update("green_stars", FieldValue.increment(1));
                                            PointToDriver.update("red_stars", FieldValue.increment(0));
                                            PointToDriver.update("yellow_stars", FieldValue.increment(0));
                                            PointToDriver.update("blue_stars", FieldValue.increment(0));
                                            PointToDriver.update("purple_stars", FieldValue.increment(0));
                                            PointToDriver.update("orange_stars", FieldValue.increment(0));
                                            checkForTagAdiv();

                                        } else {    // if FireStore points document NOT exists
                                            // means that it's the first time someone report on this driver
                                            Log.d("not exist", "Document does not exist!");
                                            Map<String, Object> DriverPoints = new HashMap<>(); // Create DriverPoints object and put data according to report type
                                            DriverPoints.put("green_stars", FieldValue.increment(1));
                                            DriverPoints.put("red_stars", FieldValue.increment(0));
                                            DriverPoints.put("yellow_stars", FieldValue.increment(0));
                                            DriverPoints.put("blue_stars", FieldValue.increment(0));
                                            DriverPoints.put("purple_stars", FieldValue.increment(0));
                                            DriverPoints.put("orange_stars", FieldValue.increment(0));
                                            PointToDriver.set(DriverPoints) // Create the FireStore points document to the driver
                                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                        private static final String TAG = "exist";

                                                        @Override
                                                        public void onSuccess(Void aVoid) {
                                                            Log.d(TAG, "DocumentSnapshot successfully written!");
                                                        }
                                                    })

                                                    .addOnFailureListener(new OnFailureListener() {
                                                        private static final String TAG = "error";

                                                        @Override
                                                        public void onFailure(@NonNull Exception e) {
                                                            Log.w(TAG, "Error writing document", e);
                                                        }
                                                    });
                                        }
                                    } else {
                                        Log.d("failed", "Failed with: ", task.getException());
                                    }
                                }
                            });

                            //  handles the pointsToReporterDriver - נהג מפרגן
                            db.collection("Drivers_Points").document(driverid)
                                    .update("pink_stars", FieldValue.increment(1))
                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                        private static final String TAG = "exist";

                                        @Override
                                        public void onSuccess(Void aVoid) {
                                            Log.d(TAG, "DocumentSnapshot successfully written!");
                                            Toast.makeText(getApplicationContext(),
                                                            "Added successfully!",
                                                            Toast.LENGTH_LONG)
                                                    .show();
                                            startActivity(new Intent(ReportFeedbackScreen.this, ReportMainScreen.class));
                                        }
                                    })

                                    .addOnFailureListener(new OnFailureListener() {
                                        private static final String TAG = "error";

                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            Log.w(TAG, "Error writing document", e);
                                        }
                                    });
                        }
                    }
                });
            }
        });
    }

    private void afterReportIstalvut() {
        Bundle extras = getIntent().getExtras();
        String car_number = extras.getString("ReportedCarKey");
        //The key argument here must match that used in the other activity
        final FirebaseFirestore db = FirebaseFirestore.getInstance();
        ImageButton afterReportIstalvutButton = (ImageButton) findViewById(R.id.istalvut);

        afterReportIstalvutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mAuth = FirebaseAuth.getInstance();
                FirebaseUser currentUser = mAuth.getCurrentUser();
                String driverid = currentUser.getUid(); //  Get the ID of the reporter driver

                //pointsToReportedDriver
                DocumentReference ReportedCarDoc = db.collection("Cars").document(car_number);   //  Get the FireStore document of the reported car
                ReportedCarDoc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            String ReportedDriverID = task.getResult().getString("driver_id");  // The id of the reported driver
                            DocumentReference PointToDriver = db.collection("Drivers_Points").document(ReportedDriverID);   //   Get the FireStore "points of driver" document
                            if (ReportedDriverID.equals(driverid)) {    // check if the driver trying to report on himself
                                Toast.makeText(getApplicationContext(),
                                                "Self Reported Not Allowed!",
                                                Toast.LENGTH_LONG)
                                        .show();
                                startActivity(new Intent(ReportFeedbackScreen.this, ReportMainScreen.class));
                            }

                            PointToDriver.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                    if (task.isSuccessful()) {
                                        DocumentSnapshot document = task.getResult();
                                        if (document.exists()) {    // check if FireStore points document exists for the reported driver
                                            // if exists, update fields according to report type:
                                            Log.d("exist", "Document exists!");
                                            PointToDriver.update("purple_stars", FieldValue.increment(1));
                                            PointToDriver.update("green_stars", FieldValue.increment(0));
                                            PointToDriver.update("yellow_stars", FieldValue.increment(0));
                                            PointToDriver.update("blue_stars", FieldValue.increment(0));
                                            PointToDriver.update("red_stars", FieldValue.increment(0));
                                            PointToDriver.update("orange_stars", FieldValue.increment(0));
                                            checkForTagAdiv();

                                        } else {    // if FireStore points document NOT exists
                                            // means that it's the first time someone report on this driver
                                            Log.d("not exist", "Document does not exist!");
                                            Map<String, Object> DriverPoints = new HashMap<>(); // Create DriverPoints object and put data according to report type
//                                                DriverPoints.put("pink_stars", 1);
                                            DriverPoints.put("purple_stars", FieldValue.increment(1));
                                            DriverPoints.put("red_stars", FieldValue.increment(0));
                                            DriverPoints.put("green_stars", FieldValue.increment(0));
                                            DriverPoints.put("yellow_stars", FieldValue.increment(0));
                                            DriverPoints.put("blue_stars", FieldValue.increment(0));
                                            DriverPoints.put("orange_stars", FieldValue.increment(0));
                                            PointToDriver.set(DriverPoints) // Create the FireStore points document to the driver
                                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                        private static final String TAG = "exist";

                                                        @Override
                                                        public void onSuccess(Void aVoid) {
                                                            Log.d(TAG, "DocumentSnapshot successfully written!");
                                                        }
                                                    })

                                                    .addOnFailureListener(new OnFailureListener() {
                                                        private static final String TAG = "error";

                                                        @Override
                                                        public void onFailure(@NonNull Exception e) {
                                                            Log.w(TAG, "Error writing document", e);
                                                        }
                                                    });
                                        }
                                    } else {
                                        Log.d("failed", "Failed with: ", task.getException());
                                    }
                                }
                            });

                            //  handles the pointsToReporterDriver - נהג מפרגן
                            db.collection("Drivers_Points").document(driverid)
                                    .update("pink_stars", FieldValue.increment(1))
                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                        private static final String TAG = "exist";

                                        @Override
                                        public void onSuccess(Void aVoid) {
                                            Log.d(TAG, "DocumentSnapshot successfully written!");
                                            Toast.makeText(getApplicationContext(),
                                                            "Added successfully!",
                                                            Toast.LENGTH_LONG)
                                                    .show();
                                            startActivity(new Intent(ReportFeedbackScreen.this, ReportMainScreen.class));
                                        }
                                    })

                                    .addOnFailureListener(new OnFailureListener() {
                                        private static final String TAG = "error";

                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            Log.w(TAG, "Error writing document", e);
                                        }
                                    });
                        }
                    }
                });
            }
        });
    }

    private void afterReportBackToRight() {
        Bundle extras = getIntent().getExtras();
        String car_number = extras.getString("ReportedCarKey");
        //The key argument here must match that used in the other activity
        final FirebaseFirestore db = FirebaseFirestore.getInstance();
        ImageButton afterReportBackToRightButton = (ImageButton) findViewById(R.id.backtoright);

        afterReportBackToRightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mAuth = FirebaseAuth.getInstance();
                FirebaseUser currentUser = mAuth.getCurrentUser();
                String driverid = currentUser.getUid(); //  Get the ID of the reporter driver

                //pointsToReportedDriver
                DocumentReference ReportedCarDoc = db.collection("Cars").document(car_number);   //  Get the FireStore document of the reported car
                ReportedCarDoc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            String ReportedDriverID = task.getResult().getString("driver_id");  // The id of the reported driver
                            DocumentReference PointToDriver = db.collection("Drivers_Points").document(ReportedDriverID);   //   Get the FireStore "points of driver" document
                            if (ReportedDriverID.equals(driverid)) {    // check if the driver trying to report on himself
                                Toast.makeText(getApplicationContext(),
                                                "Self Reported Not Allowed!",
                                                Toast.LENGTH_LONG)
                                        .show();
                                startActivity(new Intent(ReportFeedbackScreen.this, ReportMainScreen.class));
                            }

                            PointToDriver.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                    if (task.isSuccessful()) {
                                        DocumentSnapshot document = task.getResult();
                                        if (document.exists()) {    // check if FireStore points document exists for the reported driver
                                            // if exists, update fields according to report type:
                                            Log.d("exist", "Document exists!");
                                            PointToDriver.update("blue_stars", FieldValue.increment(1));
                                            PointToDriver.update("green_stars", FieldValue.increment(0));
                                            PointToDriver.update("yellow_stars", FieldValue.increment(0));
                                            PointToDriver.update("red_stars", FieldValue.increment(0));
                                            PointToDriver.update("purple_stars", FieldValue.increment(0));
                                            PointToDriver.update("orange_stars", FieldValue.increment(0));
                                            checkForTagZahir();

                                        } else {    // if FireStore points document NOT exists
                                            // means that it's the first time someone report on this driver
                                            Log.d("not exist", "Document does not exist!");
                                            Map<String, Object> DriverPoints = new HashMap<>(); // Create DriverPoints object and put data according to report type
                                            DriverPoints.put("blue_stars", FieldValue.increment(1));
                                            DriverPoints.put("red_stars", FieldValue.increment(0));
                                            DriverPoints.put("green_stars", FieldValue.increment(0));
                                            DriverPoints.put("yellow_stars", FieldValue.increment(0));
                                            DriverPoints.put("purple_stars", FieldValue.increment(0));
                                            DriverPoints.put("orange_stars", FieldValue.increment(0));
                                            PointToDriver.set(DriverPoints) // Create the FireStore points document to the driver
                                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                        private static final String TAG = "exist";

                                                        @Override
                                                        public void onSuccess(Void aVoid) {
                                                            Log.d(TAG, "DocumentSnapshot successfully written!");
                                                        }
                                                    })

                                                    .addOnFailureListener(new OnFailureListener() {
                                                        private static final String TAG = "error";

                                                        @Override
                                                        public void onFailure(@NonNull Exception e) {
                                                            Log.w(TAG, "Error writing document", e);
                                                        }
                                                    });
                                        }
                                    } else {
                                        Log.d("failed", "Failed with: ", task.getException());
                                    }
                                }
                            });

                            //  handles the pointsToReporterDriver - נהג מפרגן
                            db.collection("Drivers_Points").document(driverid)
                                    .update("pink_stars", FieldValue.increment(1))
                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                        private static final String TAG = "exist";

                                        @Override
                                        public void onSuccess(Void aVoid) {
                                            Log.d(TAG, "DocumentSnapshot successfully written!");
                                            Toast.makeText(getApplicationContext(),
                                                            "Added successfully!",
                                                            Toast.LENGTH_LONG)
                                                    .show();
                                            startActivity(new Intent(ReportFeedbackScreen.this, ReportMainScreen.class));
                                        }
                                    })

                                    .addOnFailureListener(new OnFailureListener() {
                                        private static final String TAG = "error";

                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            Log.w(TAG, "Error writing document", e);
                                        }
                                    });
                        }
                    }
                });
            }
        });
    }

    private void afterReportItut() {
        Bundle extras = getIntent().getExtras();
        String car_number = extras.getString("ReportedCarKey");
        //The key argument here must match that used in the other activity
        final FirebaseFirestore db = FirebaseFirestore.getInstance();
        ImageButton afterReportItutButton = (ImageButton) findViewById(R.id.itut);

        afterReportItutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mAuth = FirebaseAuth.getInstance();
                FirebaseUser currentUser = mAuth.getCurrentUser();
                String driverid = currentUser.getUid(); //  Get the ID of the reporter driver

                //pointsToReportedDriver
                DocumentReference ReportedCarDoc = db.collection("Cars").document(car_number);   //  Get the FireStore document of the reported car
                ReportedCarDoc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            String ReportedDriverID = task.getResult().getString("driver_id");  // The id of the reported driver
                            DocumentReference PointToDriver = db.collection("Drivers_Points").document(ReportedDriverID);   //   Get the FireStore "points of driver" document
                            if (ReportedDriverID.equals(driverid)) {    // check if the driver trying to report on himself
                                Toast.makeText(getApplicationContext(),
                                                "Self Reported Not Allowed!",
                                                Toast.LENGTH_LONG)
                                        .show();
                                startActivity(new Intent(ReportFeedbackScreen.this, ReportMainScreen.class));
                            }

                            PointToDriver.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                    if (task.isSuccessful()) {
                                        DocumentSnapshot document = task.getResult();
                                        if (document.exists()) {    // check if FireStore points document exists for the reported driver
                                            // if exists, update fields according to report type:
                                            Log.d("exist", "Document exists!");
                                            PointToDriver.update("orange_stars", FieldValue.increment(1));
                                            PointToDriver.update("red_stars", FieldValue.increment(0));
                                            PointToDriver.update("green_stars", FieldValue.increment(0));
                                            PointToDriver.update("yellow_stars", FieldValue.increment(0));
                                            PointToDriver.update("blue_stars", FieldValue.increment(0));
                                            PointToDriver.update("purple_stars", FieldValue.increment(0));
                                            checkForTagZahir();

                                        } else {    // if FireStore points document NOT exists
                                            // means that it's the first time someone report on this driver
                                            Log.d("not exist", "Document does not exist!");
                                            Map<String, Object> DriverPoints = new HashMap<>(); // Create DriverPoints object and put data according to report type
                                            DriverPoints.put("orange_stars", FieldValue.increment(1));
                                            DriverPoints.put("red_stars", FieldValue.increment(0));
                                            DriverPoints.put("green_stars", FieldValue.increment(0));
                                            DriverPoints.put("yellow_stars", FieldValue.increment(0));
                                            DriverPoints.put("blue_stars", FieldValue.increment(0));
                                            DriverPoints.put("purple_stars", FieldValue.increment(0));
                                            PointToDriver.set(DriverPoints) // Create the FireStore points document to the driver
                                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                        private static final String TAG = "exist";

                                                        @Override
                                                        public void onSuccess(Void aVoid) {
                                                            Log.d(TAG, "DocumentSnapshot successfully written!");
                                                        }
                                                    })

                                                    .addOnFailureListener(new OnFailureListener() {
                                                        private static final String TAG = "error";

                                                        @Override
                                                        public void onFailure(@NonNull Exception e) {
                                                            Log.w(TAG, "Error writing document", e);
                                                        }
                                                    });
                                        }
                                    } else {
                                        Log.d("failed", "Failed with: ", task.getException());
                                    }
                                }
                            });

                            //  handles the pointsToReporterDriver - נהג מפרגן
                            db.collection("Drivers_Points").document(driverid)
                                    .update("pink_stars", FieldValue.increment(1))
                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                        private static final String TAG = "exist";

                                        @Override
                                        public void onSuccess(Void aVoid) {
                                            Log.d(TAG, "DocumentSnapshot successfully written!");
                                            Toast.makeText(getApplicationContext(),
                                                            "Added successfully!",
                                                            Toast.LENGTH_LONG)
                                                    .show();
                                            startActivity(new Intent(ReportFeedbackScreen.this, ReportMainScreen.class));
                                        }
                                    })

                                    .addOnFailureListener(new OnFailureListener() {
                                        private static final String TAG = "error";

                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            Log.w(TAG, "Error writing document", e);
                                        }
                                    });
                        }
                    }
                });
            }
        });
    }

    public void checkForTagAdiv() {
        Bundle extras = getIntent().getExtras();
        String car_number = extras.getString("ReportedCarKey");
        DocumentReference ReportedCarDoc = db.collection("Cars").document(car_number);   //  Get the FireStore document of the reported car
        ReportedCarDoc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    String ReportedDriverID = task.getResult().getString("driver_id");  // The id of the reported driver
                    DocumentReference TagToDriver = db.collection("Drivers_Tags").document(ReportedDriverID);   //   Get the FireStore tags of driver" document
                    DocumentReference PointToDriver = db.collection("Drivers_Points").document(ReportedDriverID);   //   Get the FireStore "points of driver" document
                    Query queryPointToDriver = db.collection("Drivers_Points").whereEqualTo(FieldPath.documentId(), ReportedDriverID);

                    queryPointToDriver.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                for (QueryDocumentSnapshot document : task.getResult()) {
                                    Log.d("exist", document.getId() + " => " + document.getData());
                                    if ((document.getLong("green_stars")) >= 10 & (document.getLong("yellow_stars")) >= 10
                                            & (document.getLong("purple_stars")) >= 10) {
                                        TagToDriver.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                            @Override
                                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                                if (task.isSuccessful()) {
                                                    DocumentSnapshot document = task.getResult();
                                                    if (document.exists()) {    // check if FireStore tags document exists for the reported driver
                                                        // if exists, handle the tag:
                                                        Log.d("exist", "Document exists!");
                                                        TagToDriver.update("Adiv_tag", FieldValue.increment(1));
                                                        TagToDriver.update("Mefargen_tag", FieldValue.increment(0));
                                                        TagToDriver.update("Mitztayen_tag", FieldValue.increment(0));
                                                        TagToDriver.update("Zahir_tag", FieldValue.increment(0));

                                                        // decrease 10 points from each report type (stars):
                                                        PointToDriver.update("green_stars", FieldValue.increment(-10));
                                                        PointToDriver.update("yellow_stars", FieldValue.increment(-10));
                                                        PointToDriver.update("purple_stars", FieldValue.increment(-10));
                                                        PointToDriver.update("red_stars", FieldValue.increment(0));
                                                        PointToDriver.update("orange_stars", FieldValue.increment(0));
                                                        PointToDriver.update("blue_stars", FieldValue.increment(0));

                                                    } else {    // if FireStore tags document NOT exists
                                                        // means that it's the first time the reported driver wins a tag
                                                        Log.d("not exist", "Document does not exist!");
                                                        Map<String, Object> DriverTags = new HashMap<>(); // Create DriverTags object and put data according to report type
                                                        DriverTags.put("Adiv_tag", FieldValue.increment(1));
                                                        DriverTags.put("Mefargen_tag", FieldValue.increment(0));
                                                        DriverTags.put("Mitztayen_tag", FieldValue.increment(0));
                                                        DriverTags.put("Zahir_tag", FieldValue.increment(0));
                                                        TagToDriver.set(DriverTags) // Create the FireStore tags document to the driver
                                                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                                    private static final String TAG = "exist";

                                                                    @Override
                                                                    public void onSuccess(Void aVoid) {
                                                                        Log.d(TAG, "DocumentSnapshot successfully written!");
                                                                    }
                                                                })

                                                                .addOnFailureListener(new OnFailureListener() {
                                                                    private static final String TAG = "error";

                                                                    @Override
                                                                    public void onFailure(@NonNull Exception e) {
                                                                        Log.w(TAG, "Error writing document", e);
                                                                    }
                                                                });
                                                        // decrease 10 points from each report type (stars):
                                                        PointToDriver.update("green_stars", FieldValue.increment(-10));
                                                        PointToDriver.update("yellow_stars", FieldValue.increment(-10));
                                                        PointToDriver.update("purple_stars", FieldValue.increment(-10));
                                                        PointToDriver.update("red_stars", FieldValue.increment(0));
                                                        PointToDriver.update("orange_stars", FieldValue.increment(0));
                                                        PointToDriver.update("blue_stars", FieldValue.increment(0));

                                                    }
                                                } else {
                                                    Log.d("failed", "Failed with: ", task.getException());
                                                }
                                            }
                                        });
                                    }
                                }
                            }
                        }
                    });
                }
            }
        });
    }

    public void checkForTagZahir() {
        Bundle extras = getIntent().getExtras();
        String car_number = extras.getString("ReportedCarKey");
        DocumentReference ReportedCarDoc = db.collection("Cars").document(car_number);   //  Get the FireStore document of the reported car
        ReportedCarDoc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    String ReportedDriverID = task.getResult().getString("driver_id");  // The id of the reported driver
                    DocumentReference TagToDriver = db.collection("Drivers_Tags").document(ReportedDriverID);   //   Get the FireStore tags of driver" document
                    DocumentReference PointToDriver = db.collection("Drivers_Points").document(ReportedDriverID);   //   Get the FireStore "points of driver" document
                    Query queryPointToDriver = db.collection("Drivers_Points").whereEqualTo(FieldPath.documentId(), ReportedDriverID);

                    queryPointToDriver.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                for (QueryDocumentSnapshot document : task.getResult()) {
                                    Log.d("exist", document.getId() + " => " + document.getData());
                                    if ((document.getLong("blue_stars")) >= 10 & (document.getLong("red_stars")) >= 10
                                            & (document.getLong("orange_stars")) >= 10) {
                                        TagToDriver.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                            @Override
                                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                                if (task.isSuccessful()) {
                                                    DocumentSnapshot document = task.getResult();
                                                    if (document.exists()) {    // check if FireStore tags document exists for the reported driver
                                                        // if exists, handle the tag:
                                                        Log.d("exist", "Document exists!");
                                                        TagToDriver.update("Zahir_tag", FieldValue.increment(1));
                                                        TagToDriver.update("Adiv_tag", FieldValue.increment(0));
                                                        TagToDriver.update("Mefargen_tag", FieldValue.increment(0));
                                                        TagToDriver.update("Mitztayen_tag", FieldValue.increment(0));

                                                        // decrease 10 points from each report type (stars):
                                                        PointToDriver.update("red_stars", FieldValue.increment(-10));
                                                        PointToDriver.update("orange_stars", FieldValue.increment(-10));
                                                        PointToDriver.update("blue_stars", FieldValue.increment(-10));
                                                        PointToDriver.update("green_stars", FieldValue.increment(0));
                                                        PointToDriver.update("yellow_stars", FieldValue.increment(0));
                                                        PointToDriver.update("purple_stars", FieldValue.increment(0));


                                                    } else {    // if FireStore tags document NOT exists
                                                        // means that it's the first time the reported driver wins a tag
                                                        Log.d("not exist", "Document does not exist!");
                                                        Map<String, Object> DriverTags = new HashMap<>(); // Create DriverTags object and put data according to report type
                                                        DriverTags.put("Zahir_tag", FieldValue.increment(0));
                                                        DriverTags.put("Adiv_tag", FieldValue.increment(0));
                                                        DriverTags.put("Mefargen_tag", FieldValue.increment(0));
                                                        DriverTags.put("Mitztayen_tag", FieldValue.increment(0));
                                                        TagToDriver.set(DriverTags) // Create the FireStore tags document to the driver
                                                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                                    private static final String TAG = "exist";

                                                                    @Override
                                                                    public void onSuccess(Void aVoid) {
                                                                        Log.d(TAG, "DocumentSnapshot successfully written!");
                                                                    }
                                                                })

                                                                .addOnFailureListener(new OnFailureListener() {
                                                                    private static final String TAG = "error";

                                                                    @Override
                                                                    public void onFailure(@NonNull Exception e) {
                                                                        Log.w(TAG, "Error writing document", e);
                                                                    }
                                                                });
                                                        // decrease 10 points from each report type (stars):
                                                        PointToDriver.update("red_stars", FieldValue.increment(-10));
                                                        PointToDriver.update("orange_stars", FieldValue.increment(-10));
                                                        PointToDriver.update("blue_stars", FieldValue.increment(-10));
                                                        PointToDriver.update("green_stars", FieldValue.increment(0));
                                                        PointToDriver.update("yellow_stars", FieldValue.increment(0));
                                                        PointToDriver.update("purple_stars", FieldValue.increment(0));

                                                    }
                                                } else {
                                                    Log.d("failed", "Failed with: ", task.getException());
                                                }
                                            }
                                        });
                                    }
                                }
                            }
                        }
                    });
                }
            }
        });
    }


}
