package il.ac.pac.driveyourchangeapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class EnterReportedCar extends AppCompatActivity {

    private EditText reportedCarNumberTextView;
    private TextView ReportedDriverIDtextView;
    private Button BtnSendReportedCars;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_reported_car);

        reportedCarNumberTextView = findViewById(R.id.reported_car_number);
        BtnSendReportedCars = findViewById(R.id.chackBTNFromCars);
        BtnSendReportedCars.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkReportedCar();
            }
        });

        configureToContactFromCheckButton();


    }

    public void checkReportedCar() {
        // Take the value of two edit texts in Strings
        String reportedCarNumber = reportedCarNumberTextView.getText().toString();

        String value=reportedCarNumber;
        Intent i = new Intent(EnterReportedCar.this, ReportFeedbackScreen.class);
        i.putExtra("ReportedCarKey",value);

        final FirebaseFirestore db = FirebaseFirestore.getInstance();

        DocumentReference Cars = db.collection("Cars").document(reportedCarNumber);

        Cars.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            private static final String TAG = "exist";
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Log.d(TAG, "Document exists!");
                        Toast.makeText(getApplicationContext(),
                                        "Great, Now Choose a Report :) ",
                                        Toast.LENGTH_LONG)
                                .show();
                        startActivity(i);
                    } else {
                        Log.d(TAG, "Document does not exist!");
                        Toast.makeText(
                                    getApplicationContext(),
                                    "This car isn't in the App :(", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });

    }


    private void configureToContactFromCheckButton() {
        ImageButton ToContactFromCheckButton = (ImageButton) findViewById(R.id.homeFromcheckBTN);
        ToContactFromCheckButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(EnterReportedCar.this, ReportMainScreen.class));
            }
        });
    }


}