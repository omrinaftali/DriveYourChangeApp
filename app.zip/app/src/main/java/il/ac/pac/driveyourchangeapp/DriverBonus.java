package il.ac.pac.driveyourchangeapp;


import android.util.Log;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class DriverBonus {

    private String driver_id;
    private int bonus_number;

    public DriverBonus(String driver_id, int bonus_number) {
        this.driver_id = driver_id;
        this.bonus_number = bonus_number;
    }

    final FirebaseFirestore db = FirebaseFirestore.getInstance();
    CollectionReference DriverBonus = db.collection("Bonus_Drivers");

    public Map<String, Object> toMap() {
        final Map<String, Object> map = new HashMap<>();
        map.put("driver_id", this.driver_id);
        map.put("bonus_number", this.bonus_number);
        db.collection("Bonus_Drivers")
                .add(map)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        Log.d("exist", "DocumentSnapshot written with ID: " + documentReference.getId());
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w("not exist", "Error adding document", e);
                    }
                });
        DriverBonus.add(map);
        return map;
    }

    public static DriverPoints fromMap(Map<String, Object> data) {
        final String driver_id = (String) data.get("driver_id");
        final int bonus_number = (int) data.get("bonus_number");
        return new DriverPoints(driver_id, bonus_number);
    }

}
