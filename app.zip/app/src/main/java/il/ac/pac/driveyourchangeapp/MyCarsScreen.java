package il.ac.pac.driveyourchangeapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldPath;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.Map;

public class MyCarsScreen extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private TextView car_number_DB, car_model_DB, car_year_DB;
    private Button updateBTNFromCars;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_cars_screen);

        car_number_DB = findViewById(R.id.car_number_DB);
        car_model_DB = findViewById(R.id.car_model_DB);
        car_year_DB = findViewById(R.id.car_year_DB);
        updateBTNFromCars = findViewById(R.id.updateBTNFromCars);

        mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        String driverid = currentUser.getUid();

        FirebaseFirestore db = FirebaseFirestore.getInstance();

        CollectionReference Cars = db.collection("Cars");
        Query query = Cars.whereEqualTo("driver_id", driverid);
        query.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        Log.d("exist", document.getId() + " => " + document.getData());
                        car_number_DB.setText(document.getId());
                        car_model_DB.setText(document.getString("model"));
                        car_year_DB.setText(document.getString("year_manufacture"));
                    }
                } else {
                    Log.d("error", "Error getting documents: ", task.getException());
                }
            }
        });
        configureToHomeButtonFromMycars();
        configureButtonToEditMyCars();

    }

    private void configureToHomeButtonFromMycars(){
        ImageButton toHomeButtonFromMyCars = (ImageButton) findViewById(R.id.homeFromMyCarsBTN);
        toHomeButtonFromMyCars.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MyCarsScreen.this, ReportMainScreen.class));
            }
        });
    }

    private void configureButtonToEditMyCars(){
        Button ButtonToEditMyCars = (Button) findViewById(R.id.updateBTNFromCars);
        ButtonToEditMyCars.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MyCarsScreen.this, EditMyCarsScreen.class));
            }
        });
    }

}

