package il.ac.pac.driveyourchangeapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.content.Intent;
import android.text.TextUtils;
import android.view.View;
import android.widget.Toast;
import android.widget.EditText;
import android.widget.Button;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.AuthResult;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class RegisterScreen extends AppCompatActivity {

    private EditText emailTextView, passwordTextView, fnameTextView, lnameTextView, phoneTextView;
    private Button Btn;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_screen);

        // taking FirebaseAuth instance
        mAuth = FirebaseAuth.getInstance();

        // initialising all views through id defined above
        emailTextView = findViewById(R.id.signupEmail);
        passwordTextView = findViewById(R.id.signupPassword);
        fnameTextView =  findViewById(R.id.signupFname);
        lnameTextView =  findViewById(R.id.signupLname);
        phoneTextView =  findViewById(R.id.signupPhone);
        Btn = findViewById(R.id.registerButton);

        // Set on Click Listener on Registration button
        Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                registerNewUser();
            }
        });
    }

    private void registerNewUser()
    {
        // Take the value of two edit texts in Strings
        String email = emailTextView.getText().toString();
        String password = passwordTextView.getText().toString();
        String fname = fnameTextView.getText().toString();
        String lname = lnameTextView.getText().toString();
        String phone = phoneTextView.getText().toString();

        // Validations for input email and password
        if (TextUtils.isEmpty(email)) {
            Toast.makeText(getApplicationContext(),
                            "Please enter email!!",
                            Toast.LENGTH_LONG)
                    .show();
            return;
        }
        if (TextUtils.isEmpty(password)) {
            Toast.makeText(getApplicationContext(),
                            "Please enter password!!",
                            Toast.LENGTH_LONG)
                    .show();
            return;
        }

        // create new user or register new user
        mAuth
                .createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {

                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task)
                    {
                        if (task.isSuccessful()) {
                            Toast.makeText(getApplicationContext(),
                                            "Registration successful!",
                                            Toast.LENGTH_LONG)
                                    .show();

                            //add the user to the Drivers collection
                            final String userID=task.getResult().getUser().getUid();
                            final String email=task.getResult().getUser().getEmail();
                            final Driver driver =new Driver(userID,email,fname,lname,phone);

                            final FirebaseFirestore db = FirebaseFirestore.getInstance();
                            db.collection("Drivers").
                                    document(userID).
                                    set(driver.toMap()).addOnSuccessListener(new OnSuccessListener<Void>() {
                                        @Override
                                        public void onSuccess(Void aVoid) {
//                                            Log.d(TAG, "DocumentSnapshot added with ID: " + documentReference.getId());
                                            // if the user created intent to login activity
                                            Intent intent
                                                    = new Intent(RegisterScreen.this,
                                                    LoginScreen.class);
                                            startActivity(intent);
                                        }
                                    });
                        }
                        else {

                            // Registration failed
                            Toast.makeText(
                                            getApplicationContext(),
                                            "Registration failed!!"
                                                    + " Please try again later",
                                            Toast.LENGTH_LONG)
                                    .show();

                        }
                    }
                });
    }
}

