package il.ac.pac.driveyourchangeapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FieldPath;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class MefargenDriver extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private TextView pinkstar_DB;
    int pink;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mefargen_driver);

        pinkstar_DB = findViewById(R.id.pinkstar_DB);

        mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        String driverid = currentUser.getUid();

        FirebaseFirestore db = FirebaseFirestore.getInstance();

        CollectionReference drivers = db.collection("Drivers_Points");
        Query query = drivers.whereEqualTo(FieldPath.documentId(), driverid);
        query.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        Log.d("exist", document.getId() + " => " + document.getData());
                        if((document.getLong("pink_stars")) == null){
                            pink = 0;}
                        else{
                            pink = Math.toIntExact(document.getLong("pink_stars"));}
                        pinkstar_DB.setText(String.valueOf(pink)+ "/30");

                    }
                } else {
                    Log.d("error", "Error getting documents: ", task.getException());
                }
            }
        });
        configureToHomeFromMefargenButton();
    }

    private void configureToHomeFromMefargenButton(){
        ImageButton configureToHomeFromMefargenButton = (ImageButton) findViewById(R.id.homeFromMefargenBTN);
        configureToHomeFromMefargenButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MefargenDriver.this, ReportMainScreen.class));
            }
        });
    }

}