package il.ac.pac.driveyourchangeapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FieldPath;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class MitztayenDriver extends AppCompatActivity {


    private FirebaseAuth mAuth;
    private TextView adiv_DB, zahir_DB;
    int adiv, zahir;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mitztayen_driver);

        adiv_DB = findViewById(R.id.adiv_DB);
        zahir_DB = findViewById(R.id.zahir_DB);


        mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        String driverid = currentUser.getUid();

        FirebaseFirestore db = FirebaseFirestore.getInstance();

        CollectionReference drivers = db.collection("Drivers_Tags");
        Query query = drivers.whereEqualTo(FieldPath.documentId(), driverid);
        query.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        Log.d("exist", document.getId() + " => " + document.getData());
                        if((document.getLong("Adiv_tag")) == null){
                            adiv = 0;}
                        else{
                            adiv = Math.toIntExact(document.getLong("Adiv_tag"));}
                        adiv_DB.setText(String.valueOf(adiv)+ "/1");

                        if((document.getLong("blue_stars")) == null){
                            zahir = 0;}
                        else{
                            zahir = Math.toIntExact(document.getLong("Zahir_tag"));}
                        zahir_DB.setText(String.valueOf(zahir)+ "/1");

                    }
                } else {
                    Log.d("error", "Error getting documents: ", task.getException());
                }

            }
        });
        configureToHomeFromMitztayenButton();
    }

    private void configureToHomeFromMitztayenButton(){
        ImageButton ToHomeFromMitztayenButton = (ImageButton) findViewById(R.id.homeFromMitztayenBTN);
        ToHomeFromMitztayenButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MitztayenDriver.this, ReportMainScreen.class));
            }
        });
    }
}