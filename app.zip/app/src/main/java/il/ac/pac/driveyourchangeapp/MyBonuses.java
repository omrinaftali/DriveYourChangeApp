package il.ac.pac.driveyourchangeapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.smarteist.autoimageslider.IndicatorView.animation.type.IndicatorAnimationType;
import com.smarteist.autoimageslider.SliderAnimations;
import com.smarteist.autoimageslider.SliderView;

public class MyBonuses extends AppCompatActivity {

    int cafe_maafe = R.drawable.cafe_maafe;
    int sfipahamisithinam = R.drawable.sfipahamisithinam;

    SliderView sliderView;
    int[] images = {cafe_maafe,sfipahamisithinam};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_bonuses);

        sliderView = findViewById(R.id.image_slider);
        SliderAdapter sliderAdapter = new SliderAdapter(images);

        sliderView.setSliderAdapter(sliderAdapter);
        sliderView.setIndicatorAnimation(IndicatorAnimationType.WORM);
        sliderView.setSliderTransformAnimation(SliderAnimations.DEPTHTRANSFORMATION);
        sliderView.startAutoCycle();

        configureToHoneFromMyPickedBonusesButton();
        configuretoCoffeFromMyBonusesButton();
    }


    private void configureToHoneFromMyPickedBonusesButton(){
        ImageButton ToHoneFromMyPickedBonusesButton = (ImageButton) findViewById(R.id.homeFromMyBonuses);
        ToHoneFromMyPickedBonusesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MyBonuses.this, ReportMainScreen.class));
            }
        });
    }

    private void configuretoCoffeFromMyBonusesButton(){
        Button configuretoCoffeFromMyBonusesButton = (Button) findViewById(R.id.toCoffeFromMyBonuses);
        configuretoCoffeFromMyBonusesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MyBonuses.this, MyBonuses.class));
            }
        });
    }
}