package il.ac.pac.driveyourchangeapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FieldPath;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class ReportMainScreen extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private TextView name_loged_In_DB;
    private Button ReportButton;
    private PopupWindow popupWindow;
    private LayoutInflater layoutInflater;
    private RelativeLayout relativeLayout;
    static final int REQUEST_IMAGE_CAPTURE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_main_screen);

        name_loged_In_DB = findViewById(R.id.name_loged_In_DB);

        mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        String driverid = currentUser.getUid();

        FirebaseFirestore db = FirebaseFirestore.getInstance();

        CollectionReference drivers = db.collection("Drivers");
        Query query = drivers.whereEqualTo(FieldPath.documentId(), driverid);
        query.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                              @Override
                                              public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                                  if (task.isSuccessful()) {
                                                      for (QueryDocumentSnapshot document : task.getResult()) {
                                                          Log.d("exist", document.getId() + " => " + document.getData());
                                                          name_loged_In_DB.setText(document.getString("fname") +" "+(document.getString("lname")));
                                                      }
                                                  } else {
                                                      Log.d("error", "Error getting documents: ", task.getException());
                                                  }
                                              }
                                          });
        configureToFeedbackButton();
        configureToPersonalButton();
        configureToContactButton();
        mAuth = FirebaseAuth.getInstance();



//        ReportButton = (Button) findViewById(R.id.circle_report_button);
//        relativeLayout = (RelativeLayout) findViewById(R.id.Relative);
//
//        ReportButton.setOnClickListener(new View.OnClickListener(){
//            @Override
//            public void onClick(View view){
//                layoutInflater = (LayoutInflater) getApplicationContext().getSystemService(LAYOUT_INFLATER_SERVICE);
//                ViewGroup container = (ViewGroup) layoutInflater.inflate(R.layout.popup_window,null);
//                popupWindow = new PopupWindow(container,400,400, true);
//                popupWindow.showAtLocation(relativeLayout,Gravity.NO_GRAVITY,500,500);
//
//                container.setOnTouchListener(new View.OnTouchListener(){
//                    @Override
//                    public boolean onTouch(View view,MotionEvent motionEvent){
//                        popupWindow.dismiss();
//                        return true;
//                    }
//                });
//            }
//        });//popupwindots to car number//popupwindots to car number//popupwindots to car number
        //popupwindows to car number

    }


    private void configureToFeedbackButton() {
        Button toFeedbackButton = (Button) findViewById(R.id.circle_report_button);
        toFeedbackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ReportMainScreen.this, EnterReportedCar.class));
            }
        });
    }

    //Open Camera Work!!
//    private void configureToFeedbackButton() {
//        Button toFeedbackButton = (Button) findViewById(R.id.circle_report_button);
//        toFeedbackButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
//                try {
//                startActivityForResult(takePictureIntent,REQUEST_IMAGE_CAPTURE);
//            } catch (ActivityNotFoundException e) { // display error state to the user
//            }
//            }
//        });
//    }
//Open Camera Work!!

    private void configureToPersonalButton() {
        ImageButton toPersonalButton = (ImageButton) findViewById(R.id.personalTestBTN);
        toPersonalButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ReportMainScreen.this, PersonalAreaScreen.class));
            }
        });
    }

    private void configureToContactButton() {
        ImageButton ToContactButton = (ImageButton) findViewById(R.id.contactBTN);
        ToContactButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ReportMainScreen.this, ContactScreen.class));
            }
        });
    }


}
