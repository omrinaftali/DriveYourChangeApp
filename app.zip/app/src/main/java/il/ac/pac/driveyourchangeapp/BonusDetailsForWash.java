package il.ac.pac.driveyourchangeapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class BonusDetailsForWash extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bonus_details_for_wash);
    }
}