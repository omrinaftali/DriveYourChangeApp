package il.ac.pac.driveyourchangeapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FieldPath;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class ZahirDriver extends AppCompatActivity {


    private FirebaseAuth mAuth;
    private TextView redstar_DB, bluestar_DB, orangestar_DB, sumText;
    int sum ,red, blue, orange , adivTag;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zahir_driver);

        redstar_DB = findViewById(R.id.redstar_DB);
        bluestar_DB = findViewById(R.id.bluestar_DB);
        orangestar_DB = findViewById(R.id.orangestar_DB);

        mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        String driverid = currentUser.getUid();

        FirebaseFirestore db = FirebaseFirestore.getInstance();

        CollectionReference drivers = db.collection("Drivers_Points");
        Query query = drivers.whereEqualTo(FieldPath.documentId(), driverid);
        query.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        Log.d("exist", document.getId() + " => " + document.getData());
                        if((document.getLong("red_stars")) == null){
                            red = 0;}
                        else{
                            red = Math.toIntExact(document.getLong("red_stars"));}
                        redstar_DB.setText(String.valueOf(red)+ "/10");

                        if((document.getLong("blue_stars")) == null){
                            blue = 0;}
                        else{
                            blue = Math.toIntExact(document.getLong("blue_stars"));}
                        bluestar_DB.setText(String.valueOf(blue)+ "/10");

                        if((document.getLong("orange_stars")) == null){
                            orange = 0;}
                        else{
                            orange = Math.toIntExact(document.getLong("orange_stars"));}
                        orangestar_DB.setText(String.valueOf(orange) + "/10");

                    }
                } else {
                    Log.d("error", "Error getting documents: ", task.getException());
                }

            }
        });
        configureToHomeFromZahirButton();
    }

    private void configureToHomeFromZahirButton(){
        ImageButton ToHomeFromZahirButton = (ImageButton) findViewById(R.id.homeFromZahirBTN);
        ToHomeFromZahirButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ZahirDriver.this, ReportMainScreen.class));
            }
        });
    }

}