package il.ac.pac.driveyourchangeapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FieldPath;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.Map;

public class BonusDetails extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private TextView Bonus_title_DB, Bonus_area_DB, expired_date_DB,Conditions_DB,notes_DB;
    private ImageView Bonus_image;
    String bonusImageName = String.valueOf(Bonus_image.getTag());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bonus_details);

        Bonus_image = findViewById(R.id.cafe_maafe);

        Bonus_title_DB = findViewById(R.id.Bonus_title_DB);
        Bonus_area_DB = findViewById(R.id.Bonus_area_DB);
        expired_date_DB = findViewById(R.id.expired_date_DB);
        Conditions_DB = findViewById(R.id.Conditions_DB);
        notes_DB = findViewById(R.id.notes_DB);

        mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        String driverid = currentUser.getUid();

        FirebaseFirestore db = FirebaseFirestore.getInstance();
        createNewBonusBarcodeForDriver();



        CollectionReference Bonuses = db.collection("Bonuses");
//        Query query = Bonuses.whereEqualTo("driver_id", driverid);
        Query query = Bonuses.whereEqualTo(FieldPath.documentId(),bonusImageName);
        query.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        Log.d("exist", document.getId() + " => " + document.getData());
                        Bonus_title_DB.setText(document.getString("title"));
                        Bonus_area_DB.setText(document.getString("area"));
                        expired_date_DB.setText(document.getString("expired_date"));
                        Conditions_DB.setText(document.getString("Conditions"));
                        notes_DB.setText(document.getString("notes"));
                    }
                } else {
                    Log.d("error", "Error getting documents: ", task.getException());
                }
            }
        });
    }

    private void createNewBonusBarcodeForDriver() {
//
//        Bundle extras = getIntent().getExtras();
//        String value = extras.getString("ReportedCarKey");
        //The key argument here must match that used in the other activity
        final FirebaseFirestore db = FirebaseFirestore.getInstance();
        Button afterChooseBonusButton = (Button) findViewById(R.id.chooseBonus);

        afterChooseBonusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //pointsToReportedDriver

                mAuth = FirebaseAuth.getInstance();
                FirebaseUser currentUser = mAuth.getCurrentUser();
                String driver_id = currentUser.getUid();

                Map<String, Object> DriverBonus = new HashMap<>();
                DriverBonus.put("driver_id", driver_id);
                DriverBonus.put("bonus_name", bonusImageName);

                db.collection("Bonus_Drivers")
                        .add(DriverBonus)
                        .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                            @Override
                            public void onSuccess(DocumentReference documentReference) {
                                Log.d("exist", "DocumentSnapshot written with ID: " + documentReference.getId());
                                startActivity(new Intent(BonusDetails.this, BonusDetailsForCoffeeWithBarcode.class));
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.w("not exist", "Error adding document", e);
                            }
                        });
            }
        });
    }
}