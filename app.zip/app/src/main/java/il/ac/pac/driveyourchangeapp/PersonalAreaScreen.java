package il.ac.pac.driveyourchangeapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class PersonalAreaScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_area_screen);


        configureToHomeFromPersonalButton();
        configureToPersonalDetailsButton();
        configureToMyCarsButtonFromArea();
        configureToBonusesButtonFromArea();
        configureToAdivFromPersonalButton();
        configureToZahirFromPersonalButton();
        configureToMefargenFromPersonalButton();
        configureToMiztayenFromPersonalButton();
    }

    private void configureToHomeFromPersonalButton() {
        ImageButton toHomeButton2 = (ImageButton) findViewById(R.id.homeFromPersonalBTN);
        toHomeButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(PersonalAreaScreen.this, ReportMainScreen.class));
            }
        });
    }


    private void configureToPersonalDetailsButton() {
        Button ToPersonalDetails = (Button) findViewById(R.id.personal_details_BTN);
        ToPersonalDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(PersonalAreaScreen.this, PersonalDetailsScreen.class));
            }
        });
    }

    private void configureToMyCarsButtonFromArea() {
        Button ToMyCarsButtonFromArea = (Button) findViewById(R.id.myCarsBTN);
        ToMyCarsButtonFromArea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(PersonalAreaScreen.this, MyCarsScreen.class));
            }
        });
    }

    private void configureToBonusesButtonFromArea() {
        Button ToBonusesButtonFromArea = (Button) findViewById(R.id.myBonus);
        ToBonusesButtonFromArea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(PersonalAreaScreen.this, Bonuses.class));
            }
        });
    }

    private void configureToAdivFromPersonalButton() {
        ImageButton configureToAdivFromPersonalButton = (ImageButton) findViewById(R.id.adiv);
        configureToAdivFromPersonalButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(PersonalAreaScreen.this, AdivDriver.class));
            }
        });
    }


    private void configureToZahirFromPersonalButton() {
        ImageButton onfigureToZahirFromPersonalButton = (ImageButton) findViewById(R.id.Zahir);
        onfigureToZahirFromPersonalButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(PersonalAreaScreen.this, ZahirDriver.class));
            }
        });
    }

    private void configureToMefargenFromPersonalButton() {
        ImageButton configureToMefargenFromPersonalButton = (ImageButton) findViewById(R.id.Mefargen);
        configureToMefargenFromPersonalButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(PersonalAreaScreen.this, MefargenDriver.class));
            }
        });
    }

    private void configureToMiztayenFromPersonalButton() {
        ImageButton configureToMiztayenFromPersonalButton = (ImageButton) findViewById(R.id.Mitztayen);
        configureToMiztayenFromPersonalButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(PersonalAreaScreen.this, MitztayenDriver.class));
            }
        });
    }
}